import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import ddf.minim.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class PADprocessing extends PApplet {



Minim minim;
Screens screens;
RoundCounter counter;
Style style;
Bankrun bankrun;
GameEndingTracker gameEndingTracker;
Glossary glossary;
Sounds sounds;
int screen = 1;
int amountOfPlayers;
int count;
// 0 voor beginners versie, 1 voor volledige versie.
int version;

public void setup()
{
  
  minim = new Minim(this);
  sounds = new Sounds();
  screens = new Screens();
  style = new Style();
  counter = new RoundCounter();
  bankrun = new Bankrun();
  gameEndingTracker = new GameEndingTracker();
  glossary = new Glossary();
  textAlign(CENTER);
  rectMode(CENTER);
}

public void draw()
{
  background(style.backgroundColor);
  //println(screen);
  println("Screen " + screen);
  println("turn " + counter.turn);
  println("round " + counter.round);
  println("bankrun " + bankrun.bankrunCount);
  counter.Count();

  bankrun.bankrunTrigger();
  bankrun.bankrunDisplay();

  glossary.glossaryUpdateDraw();

  if(mousePressed){
    if(sounds.buttonPush.position() == sounds.buttonPush.length()){
      sounds.buttonPush.rewind();
    }
    if(sounds.bankrun.position() == sounds.bankrun.length()){
      sounds.bankrun.rewind();
    }
  }


  if (glossary.glossaryState == GLOSSARY_DORMENT) {
    switch(screen)
    {
    case 1:
      screens.screen1();
      return;

    case 2:
      screens.screen2();
      return;

    case 3:
      screens.screen3();
      return;

    case 4:
      screens.screen4();
      return;

    case 5:
      screens.screen5();
      return;

    case 6:
      screens.screen6();
      return;

    case 7:
      screens.screen7();
      return;

    case 8:
      screens.screen8();
      return;

    case 9:
      screens.screen9();
      return;

    case 10:
      screens.screen10();
      return;

    case 11:
      screens.screen11();
      return;

    case 12:
      screens.screen12();
      return;

    case 13:
      screens.screen13();
      return;

    case 14:
      screens.screen14();
      return;

    case 15:
      screens.screen15();
      return;

    case 16:
      screens.screen16();
      return;

    case 17:
      screens.screen17();
      return;

    case 18:
      screens.screen18();
      return;

    case 19:
      screens.screen19();
      return;

    case 20:
      screens.screen20();
      return;

    case 21:
      screens.screen21();
      return;

    case 22:
      screens.screen22();
      return;

    case 23:
      screens.screen23();
      return;

    case 24:
      screens.screen24();
      return;

    case 25:
      screens.screen25();
      return;

    case 26:
      screens.screen26();
      return;

    case 27:
      screens.screen27();
      return;

    case 28:
      screens.screen28();
      return;

    case 29:
      screens.screen29();
      return;

    case 30:
      screens.screen30();
      return;

    case 31:
      screens.screen31();
      return;

    case 32:
      screens.screen32();
      return;

    case 33:
      screens.screen33();
      return;

    case 34:
      screens.screen34();
      return;

    case 35:
      screens.screen35();
      return;

    case 36:
      screens.screen36();
      return;

    case 37:
      screens.screen37();
      return;

    case 38:
      screens.screen38();
      return;

    case 39:
      screens.screen39();
      return;

    case 40:
      screens.screen40();
      return;

    case 41:
      screens.screen41();
      return;

    case 42:
      screens.screen42();
      return;

    case 43:
      screens.screen43();
      return;

    case 44:
      screens.screen44();
      return;

    case 45:
      screens.screen45();
      return;

    case 46:
      screens.screen46();
      return;

    case 47:
      screens.screen47();
      return;

    case 48:
      screens.screen48();
      return;

    case 49:
      screens.screen49();
      return;

    case 50:
      screens.screen50();
      return;

    case 51:
      screens.screen51();
      return;

    case 52:
      screens.screen52();
      return;

    case 53:
      screens.screen53();
      return;

    case 54:
      screens.screen54();
      return;

    case 55:
      screens.screen55();
      return;

    case 56:
      screens.screen56();
      return;

    case 57:
      screens.screen57();
      return;

    case 58:
      screens.screen58();
      return;

    case 59:
      screens.screen59();
      return;

    case 60:
      screens.screen60();
      return;
    }
  }
}

//Enter the coördinates (x0, y0) and the sizes (w0, h0) of the rect you want to calculate the overlap with.
//Also enter the x and y position of the mouse (x1, y1)
//NOTE: this only works when the rect is in rectMode(CENTER).
public boolean overlaps(float x0, float y0, float w0, float h0, float x1, float y1)
{
  if (x1 > (x0 - w0/2) && x1 < (x0 + w0/2) && y1 > (y0 - h0/2) && y1 < (y0 + h0/2))
  {
    return true;
  } else
  {
    return false;
  }
}

//This function draws a rectangle in the bottom left corner of the screen
//When it is clicked the screen changes to the screen number given in the paramater of this function
//Count makes it impossible for the player to accidentally skip a screen
public void previous(int previousScreen)
{
  rectMode(CENTER);
  fill(style.white);
  image(style.linkerPijl, 100, 865, 100, 50);
  count++;
  if (overlaps(100, 850, 100, 50, mouseX, mouseY) && mousePressed && count > 40)
  {
    sounds.buttonPush.play();
    screen = previousScreen;
    count = 0;
  }
}

//This function draws a rectangle in the bottom right corner of the screen
//When it is clicked the screen changes to the screen number given in the paramater of this function
//Count makes it impossible for the player to accidentally skip a screen
public void next(int nextScreen)
{
  rectMode(CENTER);
  fill(style.white);
  image(style.rechterPijl, 1500, 865, 100, 50);
  count++;
  if (bankrun.bankrun)
  {
    if (version == 0) {
      screen = 26;
    }
    if (version == 1) {
      screen = 58;
    }
    return;
  }
  if (overlaps(1500, 865, 100, 50, mouseX, mouseY) && mousePressed && count > 40)
  {
    sounds.buttonPush.play();
    screen = nextScreen;
    count = 0;
  }
}
class Avatar{
  Avatar(){
  
  
  }
  
  public void Emote(){
  
  
  }
}
class Bankrun 
{
  public int bankrunCount;
  public boolean bankrunThisTurn;
  public boolean bankrun;
  public int amountOfBankrunFiches;
  public int bankrunFichesLeft;
  public int fichesLeftOnPile;

  int bankrunSteps;
  Bankrun() {
    bankrunCount = 0;
    bankrunThisTurn = false;
    bankrun = false;
    bankrunSteps = amountOfPlayers +1;
    bankrunFichesLeft = amountOfBankrunFiches;
  }

  //Dit is de functie voor het fiche dat op het biedscherm gedisplayed wordt
  //Hier kan dan op geklikt worden als er op het begin van de beurt al 5 kaarten open liggen
  public void bankrunFiche()
  {
    imageMode(CENTER);
    image(style.bankrunfiche, 1150, 790, 275, 250);
    count++;
    if (overlaps(1150, 790, 275, 250, mouseX, mouseY) && mousePressed && count > 20)
    {
      bankrunCount += 1;
      screen = 24;
      bankrunThisTurn = true;
      sounds.bankrun.play();
    }
  }

  //Dit is de functie die checkt of het fiche de bankrunmeter bereikt heeft
  //Als dat true is wordt er ook nog gecheckt of dit het laatste fiche was, als dat zo is eindigt de game
  public void bankrunTrigger()
  {
    if (bankrunCount >= bankrunSteps)
    {
      bankrun = true;
      bankrunCount = 0;
      bankrunFichesLeft--;
      gameEndingTracker.gameEnd();
    }
  }

  //Deze functie zorgt ervoor dat de fiches en het aantal stappen linksboven in het scherm gedisplayed worden
  public void bankrunDisplay()
  {
    fichesLeftOnPile = bankrunFichesLeft;
    int number;
    int coinX = 50;
    int coinY = 50;

    //Hier worden de cirkels gedrawed, de ingewikkelde berekeningen en getallen zorgen ervoor dat het patroon zig-zaggend is
    //Het aantal cirkels hangt ook af van het aantal spelers
    for (int i = 0; i <= amountOfPlayers; i++)
    {
      noFill();
      if (i % 2 != 0) {
        number = 60;
      } else {
        number = 0;
      }
      ellipse((50 + 75*i), 50 + number, 75, 75);
      if (i == amountOfPlayers) {
        ellipse(150 + 75*i, 75, 75, 75);
      }
    }

    //Dit is de coin die op de eerste cirkel staat (De stapel waar alle coins op het begin van de game staan)
    //Het aantal coins op de stapel wordt eronder gedisplayed met een getal
    imageMode(CENTER);
    if (bankrunCount != 0 && bankrunFichesLeft > 1)
    {
      image(style.bankruncoin, 50, 50, 78, 78);
    }
    //Dit if statement zorgt ervoor dat het getal onder de stapel fiches 1 minder wordt als 
    //er een fiche van de stapel naar een volgende stap wordt verplaatst
    if (bankrunCount > 0) {
      fichesLeftOnPile--;
    }

    //Zolang er nog fiches op de stapel liggen, blijft het getal eronder zichtbaar
    //Als het laatste fiche van de stapel een stap vooruit gaat, verdwijnt dit getal
    if (fichesLeftOnPile != 0)
    {
      textSize(20); 
      fill(style.white);
      text(fichesLeftOnPile, 50, 110);
      textSize(50);
    }

    //Dit if statement zorgt ervoor dat het fiche stappen zet
    if (bankrunCount <= bankrunSteps)
    {
      coinX = 50+ (75 * bankrunCount);
      //Hierdoor zig-zagt het fiche zodat het op de cirkels gedisplayed wordt
      if (bankrunCount % 2 != 0)
      {
        coinY += 60;
      }
    }

    //Hier wordt het fiche op de laatste cirkel gezet als het max aantal stappen bereikt is
    if (bankrun)
    {
      coinX = 150 + (75*amountOfPlayers); 
      coinY = 75;
    }
    image(style.bankruncoin, coinX, coinY, 78, 78);
  }
}
class GameEndingTracker
{
  Boolean gameFinished;
  
  GameEndingTracker() 
  {
    gameFinished = false;
  }

  public void gameEnd()
  {
    if (bankrun.bankrunFichesLeft <= 0)
    {
      gameFinished = true;
      screen = 56;
    }
  }
}
final int GLOSSARY_OPENING = 1;
final int GLOSSARY_OPEN = 2;
final int GLOSSARY_ELEMENT_OPEN = 3;
final int GLOSSARY_DORMENT = 0;
final int GLOSSARY_INVISIBLE = -1;
final int GLOSSARY_STARTING_XPOS = 1600;
final int GLOSSARY_HORZ_OFFSET = 450;
final int GLOSSARY_OBJECT_AMOUNT = 12;
final int GLOSSARY_OBJECT_COLUMNS = 4;
final int GLOSSARY_OBJECT_OBJECTSPERCOLUMN = 3;
final int GLOSSARY_OBJECT_WH = 100;
final int GLOSSARY_ELEMENT_TEXT_XOFFSET = width - width / 3;

class Glossary
{

  int glossaryPosXpos;
  int glossaryPosYpos;

  int theButtonXpos;
  int theButtonYpos;

  int glossarySizeX;
  int glossarySizeY;
  int glossaryState;
  int currentElement;

  int navigationTimer;

  final int GLOSSARY_OPENBUTTON_XPOS = width - 100;
  final int GLOSSARY_OPENBUTTON_YPOS = 100;
  final int AVATAR_XPOS = 200;
  final int AVATAR_YPOS = height - (height / 3);

  Glossary() { //constructor for the glossary
    glossaryState = 0;
    glossaryPosXpos = 1650;
    glossaryPosYpos = 0;
    glossarySizeX = 50;
    currentElement = -1;
    navigationTimer = 0;

    glossarySizeY = height;
  }

  public void glossaryUpdateDraw() { //function that runs all the necessary functions for the glossary to function
    rectMode(CORNER);
    drawGlossary();
    glossaryPosCheck();
    rectMode(CENTER);
  }

  public void glossaryPosCheck() { //function that checks whether or not the button to display the glossary has been clicked

    navigationTimer--;

    if (glossaryState == GLOSSARY_OPEN && mouseX < 50 && mousePressed == true)
    {
      currentElement = -1;
      glossaryState = GLOSSARY_DORMENT;
    }

    if (mouseX > 1600 && mousePressed == true && glossaryState == GLOSSARY_DORMENT || overlaps(GLOSSARY_OPENBUTTON_XPOS, GLOSSARY_OPENBUTTON_YPOS, 150, 150, mouseX, mouseY) && mousePressed) {
      glossaryState = GLOSSARY_OPENING;
    }
    if (glossaryState == GLOSSARY_OPEN) {
      for (int i = 0; i < GLOSSARY_OBJECT_COLUMNS; i++) {
        for (int j = 0; j < GLOSSARY_OBJECT_OBJECTSPERCOLUMN; j++) {
          if (mouseX > GLOSSARY_HORZ_OFFSET + (i * 200) && mouseX < GLOSSARY_HORZ_OFFSET + (i * 200) + GLOSSARY_OBJECT_WH && mouseY > 200 + (j * 200) && mouseY < 200 + (j * 200) + GLOSSARY_OBJECT_WH && mousePressed == true) {

            currentElement = i + (4 * j);

            currentElement = i + (3 * j);
            if (mouseY > 350) {
              currentElement += 1;
            }
            if (mouseY > 550) {
              currentElement += 1;
            }

            glossaryState = GLOSSARY_ELEMENT_OPEN;
          }
        }
      }
    }
    if (glossaryState == GLOSSARY_ELEMENT_OPEN) {
      if (mouseX < 50 && mousePressed == true)
      {
        currentElement = -1;
        glossaryState = GLOSSARY_DORMENT;
      }
    }

    if (overlaps(100, 850, 100, 50, mouseX, mouseY) && mousePressed && navigationTimer <= 0)
    {
      if (glossaryState == GLOSSARY_OPEN) {
        glossaryState = GLOSSARY_DORMENT;
      }
      if (glossaryState == GLOSSARY_ELEMENT_OPEN) {
        glossaryState = GLOSSARY_OPEN;
        navigationTimer = 40;
      }
    }
  }

  public void drawGlossary() {
    fill(7, 53, 90);

    switch (glossaryState) {
    case GLOSSARY_OPENING:
      if (glossaryPosXpos > 0) {
        glossaryPosXpos -= 15;

        glossarySizeX += 15;
      } else {
        glossaryState = GLOSSARY_OPEN;
      }

      rect(glossaryPosXpos, glossaryPosYpos, glossarySizeX, glossarySizeY);
      break;

    case GLOSSARY_DORMENT:
      if (glossaryPosXpos < GLOSSARY_STARTING_XPOS) {
        glossaryPosXpos += 15;
        glossarySizeX -= 15;
      }
      rect(glossaryPosXpos, glossaryPosYpos, glossarySizeX, glossarySizeY);
      image(style.glossaryKnop, GLOSSARY_OPENBUTTON_XPOS, GLOSSARY_OPENBUTTON_YPOS, 150, 150);
      break;

    case GLOSSARY_OPEN:
      textSize(style.textSize);
      rect(glossaryPosXpos, glossaryPosYpos, glossarySizeX, glossarySizeY);
      image(style.linkerPijl, 100, 865, 100, 50);
      fill(style.white);

      text("Regelboekje", width/2, height/8);
      fill(style.white);
      for (int i = 0; i < GLOSSARY_OBJECT_COLUMNS; i++) {
        for (int j = 0; j < GLOSSARY_OBJECT_OBJECTSPERCOLUMN; j++) {
          rect(GLOSSARY_HORZ_OFFSET + 200 * i, 200 + j * 200, 100, 100);
        }
      }
      drawIcons();
      break;

    case GLOSSARY_ELEMENT_OPEN:

      rect(glossaryPosXpos, glossaryPosYpos, glossarySizeX, glossarySizeY);
      rect(theButtonXpos, theButtonYpos, glossarySizeX, glossarySizeY);
      image(style.linkerPijl, 100, 865, 100, 50);

      contentSelector(currentElement);
      break;

    case GLOSSARY_INVISIBLE:
      break;
    }
    /*fill (style.black);
     
     text (currentElement, 100, 100);
     fill(style.white);*/
  }

  public void drawIcons() { //this function supplies the glossary with the right icons
    imageMode(CORNER);
    image(style.bankruncoin, GLOSSARY_HORZ_OFFSET, 200, 100, 100);
    image(style.glossaryDobbelstenen, GLOSSARY_HORZ_OFFSET + 200, 200, 100, 100);
    image(style.glossaryPromoveren, GLOSSARY_HORZ_OFFSET + 2 * 200, 200, 100, 100);
    image(style.glossaryMarkten, GLOSSARY_HORZ_OFFSET + 3 * 200, 200, 100, 100);
    image(style.glossaryKopen, GLOSSARY_HORZ_OFFSET, 2 * 200, 100, 100);
    image(style.glossaryGoud, GLOSSARY_HORZ_OFFSET + 200, 2 * 200, 100, 100);
    image(style.glossaryKrediet, GLOSSARY_HORZ_OFFSET + 2 * 200, 2 * 200, 100, 100);
    image(style.glossaryBank, GLOSSARY_HORZ_OFFSET + 3 * 200, 2 * 200, 100, 100);
    image(style.glossaryActiekaart, GLOSSARY_HORZ_OFFSET, 3 * 200, 100, 100);
    image(style.glossaryFinancieringskaart, GLOSSARY_HORZ_OFFSET + 200, 3 * 200, 100, 100);
    image(style.glossaryGilde, GLOSSARY_HORZ_OFFSET + 2 * 200, 3 * 200, 100, 100);
    image(style.glossaryGevangenis, GLOSSARY_HORZ_OFFSET + 3 * 200, 3 * 200, 100, 100);
    imageMode(CENTER);
  }

public void contentSelector(int arrayIndex) { //this function defines what text/images/etc should be drawn in what glossarycontent object
    fill(style.black);
    // with Monnay
    switch (arrayIndex) {
    case 0: //bankrun

      fill(style.white);
      textSize(style.textSize);
      text("Bankruns", width/2, height/8);
      image(style.BagJoke, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Je mag gewoon blijven zitten hoor.", AVATAR_XPOS + 50, 200);
      fill(style.white);
      text("Een bankrun is een spel evenement dat gebeurd wanneer bepaalde condities zijn behaald.\nBij een bankrun komt het spel meteen stil te liggen.\nHet gaat pas weer verder als elke speler zijn schulden heeft afgelost.\nAls een speler zijn schulden niet kan aflossen degradeerd hij in kredietklasse en kan hij zelfs in de gevangenis belanden.\nEen bankrun onstaat wanneer een bankrunfiche het einde van de bankrunmeter bereikt of als al het goud in de goudreserve opraakt.", (width / 3) * 2, height/2);
      image(style.bankrunMeter, width/2+200, height/2+275);
      break;
    case 1: //dobbelstenen
      fill(style.white);
      textSize(style.textSize);
      text("Dobbelstenen", width/2, height/8);
      image(style.BagTip, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Als je rustig gooit kun je\nmisschien de uitkomst bepalen.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Er zijn twee soorten dobbelsteen, de kredietdobbelsteen en de wijkdobbelsteen.\nDe kredietdobbelsteen wordt aan het einde van een beurt gegooid en op basis van de worp gebeuren er bepaalde dingen.\nBij het getal 10 wordt het aantal spelers geteld die 10 of meer krediet hebben liggen op de getroffen huizenblokken.\nDe getroffen huizenblokken worden bepaald door een worp met de Wijkdobbelsteen.\nDitzelfde aantal blokjes wordt uit de markt met de corresponderende kleur gehaald. (groen/rood)\nVoor blauw worden er geen blokjes uit de markten gehaald,\ninplaats daarvan wordt het voorste bankrunfiche zoveel stappen verplaats als er getroffen spelers zijn.", (width / 3) * 2, height/2);
      image(style.r10, width/3, height/2+300, 200, 200);
      image(style.molen, width/2+500, height/4, 200, 200);
      break;
    case 2: //promoveren/degraderen
      fill(style.white);
      textSize(style.textSize);
      text("Promoveren en Degraderen", width/2, height/8);
      image(style.BagTip, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 300, 500, 400);
      textSize(16);
      fill(style.black);
      text("Als je je schulden niet kunt betalen tijdens\neen bankrun beland je in de gevangenis.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Rechtsboven op het bord zie je de kredietklassen.\nJe kunt op deze schaal promoveren en degraderen.\nPromoveren gebeurt als je in een keer schulden aflost die groter dan of gelijk zijn aan de getallen in het geel boven de kredietklassen.\nDegraderen gebeurt wanneer je tijdens een bankrun je schulden niet kunt aflossen.\nAls je degradeerd in de eerste kredietklasse beland je in de gevangenis!", (width / 3) * 2, height/2);
      image(style.kredietKlassen, width/2+200, height/2+275);
      break;
    case 3: //productie/consumptie
      fill(style.white);
      textSize(style.textSize);
      text("Productie en Consumptie", width/2, height/8);
      image(style.BagFact, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 300, 500, 400);
      textSize(16);
      fill(style.black);
      text("Het duurste eten dat je kunt kopen is\nJapans Kobe vlees van 1000 euro per kilo.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Links en rechts op het bord zie je de productie en consumptie markten.\nAlle blokjes zijn verdeeld in groepen met getallen erbij die de actuele prijs van de blokje weergeven.\nAls een blokje gekocht wordt wordt deze aan de kant met de laagste prijs genomen en betaald voor die prijs.\nHetzelfde geldt voor verkoop.", (width / 3) * 2, height/2);
      image(style.glossaryMarkten, width/2, height/2+275);
      break;
    case 4: //Kopen/Verkopen
      fill(style.white);
      textSize(style.textSize);
      text("Kopen en Verkopen", width/2, height/8);
      image(style.BagTip, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 350, 500, 400);
      textSize(16);
      fill(style.black);
      text("Later in het spel veranderen de prijzen\nvan goederen erg snel, wacht niet te lang!", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Kopen en verkopen van goederen in de groene/rode markt kan op elk moment in een beurt.\nDe getallen van het deel waar de blokjes in belanden bepalen de koop en verkoop prijs.\nStel je voor dat je vier blokjes wilt kopen uit de rode markt waarvan er twee in het deel van 4 en twee in het deel van 5 zitten.\n2 x 4 + 2 x 5 = 18 goud.", (width / 3) * 2, height/2);
      image(style.screen15, width/3, height/2+300, 250, 250);
      break;
    case 5: //goud
      fill(style.white);
      textSize(style.textSize);
      text("Goud", width/2, height/8);
      image(style.BagFact, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Ongeveer 80% van het totale aantal goud\nop aarde is al gedolven door de mensheid.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Goud is naast krediet de valuta van het spel.\nGoud is altijd hetzelfde waard en kan gebruikt worden om dingen te kopen; zoals financierings- en actiekaarten.\nGoud is de enige manier om schulden af te lossen en kan verdiend worden door productie/consumptie blokjes-\nte verkopen voor de actuele marktwaarde\n of om financieringskaarten te verhandelen met andere spelers.", (width / 3) * 2, height/2);
      image(style.gold, width/2, height/2+300, 260, 200);
      break;
    case 6: //krediet
      fill(style.white);
      textSize(style.textSize);
      text("Krediet", width/2, height/8);
      image(style.BagTip, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Als je niet met krediet hoeft te\nbetalen zou ik dat ook niet doen.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Krediet is naast goud de valuta van het spel.\nKrediet werkt als een lening, en kan net als goud gebruikt worden om financierings- en actiekaarten te kopen.\nGespendeerd krediet wordt op basis van de kredietklasse van de speler in de corresponderende wijk verdeeld over de verschillende iconen.\nTijdens een bankrun worden op basis van een gooi met de wijkdobbelsteen bepaald welke iconen in deze wijken getroffen worden.\nSpelers met schulden op die huizenblokken moeten hun schulden betalen.\n(Zie bankrun in het regelboekje voor meer uitleg)", (width / 3) * 2, height/2);
      image(style.glossaryKrediet, width/2-100, height/2+300);
      break;
    case 7: //bank
      fill(style.white);
      textSize(style.textSize);
      text("De Bank", width/2, height/8);
      image(style.BagFact, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Het woord 'bank' is een voorbeeld van een homoniem,\neen woord met meerdere betekenissen.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("De bank en de reserves zijn waar al het goud en alle productie en consumptie blokje die niet in het spel zijn worden opgeslagen.\nAls er geen goud meer is in de bank volgt er automatisch een bankrun\nen moeten alle spelers op dat moment hun schulden proberen af te betalen.", (width / 3) * 2, height/2);
      break;
    case 8: //actie kaart
      fill(style.white);
      textSize(style.textSize);
      text("Actie Kaarten", width/2, height/8);
      image(style.BagTip, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Met actie kaarten kun je het hele spel omgooien.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("De stapel groene kaarten zijn de actiekaarten.\nDeze kun je kopen voor 10 goud per stuk en hebben verschillende effecten als ze gespeeld worden.\nDe effecten van een gekochte kaart zijn alleen zichtbaar voor de speler die de kaart kocht.", (width / 3) * 2, height/2);
      image(style.glossaryActiekaart, width/2+400, height/3, 200, 200);
      break;
    case 9: //financierings kaart
      fill(style.white);
      textSize(style.textSize);
      text("Financierings Kaarten", width/2, height/8);
      image(style.BagFact, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 350, 500, 400);
      textSize(16);
      fill(style.black);
      text("Het oudste bedrijf van Nederland\nis een bierbrouwerij in Wijlre:\n de Koninklijke Brand Bierbrouwerij BV.\nAl sinds 1340 is deze brouwer actief.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("De stapel rode kaarten zijn de financieringskaarten.\ndeze stellen gebouwen/commodities voor waar je op kunt bieden en zijn de drijfveer van het spel.\nElke kaart heeft een speciale eigenschappen op basis van de getallen en plaatjes die er op staan afgebeeld.\nHieronder vallen gildes, startprijs en productie.\nElke beurt komt er een nieuwe financieringskaart bij, en als 1 speler er 10 verzameld heeft is het spel afgelopen-\nen moeten de scores worden berekend.\nLiggen er aan het begin van een beurt 5 kaarten dan beweegt het voorste bankrunfiche 1 plaats.", (width / 3) * 2, height/2);
      image(style.glossaryFinancieringskaart, width/2-200, height/2+300, 200, 200);
      break;
    case 10: //gilde
      fill(style.white);
      textSize(style.textSize);
      text("Gilde", width/2, height/8);
      image(style.BagFact, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Een gilde is een belangenorganisatie voor mensen\ndie in dezelfde beroepsgroep werken.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Financieringskaarten behoren allemaal tot een gilde.\nAls je meerdere kaarten met hetzelfde gilde hebt krijg je 1 extra stuk groene/rode productie voor elke kaart die tot hetzelfde gilde behoort.", (width / 3) * 2, height/2);
      image(style.glossaryGilde, width/2+200, height/2+200, 200, 200);
      break;
    case 11: //gevangenis
      fill(style.white);
      textSize(style.textSize);
      text("Gevangenis", width/2, height/8);
      image(style.BagJoke, AVATAR_XPOS, AVATAR_YPOS, 500, 500);
      image(style.glossarySpeech, AVATAR_XPOS + 50, AVATAR_YPOS - 400, 500, 400);
      textSize(16);
      fill(style.black);
      text("Zebras zijn eigenlijk paarden die ontsnapt\nzijn uit de gevangenis.", AVATAR_XPOS + 50, 200, 200);
      fill(style.white);
      text("Als je degradeerd naar de gevangenis (zie degraderen/promoveren voor meer uitleg) blijf je in het spel, maar kun je minder dingen doen.\n Tijdens jouw beurt mag je alle normale beurtopties uitvoeren behalve bieden op fanancieringkaarten.\n Al het goud/krediet wat je verdient in de beurt moet direct gebruikt worden om schulden te betalen.\nAls al je schulden zijn betaald promoveer je weer naar kredietklasse I\nAls je in de gevangenis zit en je je schulden niet kunt betalen tijdens een bankrun ga je failliet en is het spel voor jou over.", (width / 3) * 2, height/2);
      image(style.gevangenis, width/2+200, height/2+300, 800, 200);
      break;
    }
  }

  public boolean overlapsRectCorner(float x0, float y0, float w0, float h0, float x1, float y1) //x0, y0 coordinates | w0, h0 width/height | x1, y1 position of mouse
  {
    if (x1 > x0 && y1 > y0 && x1 < x0 + w0 && y1 < x0 + h0)
    {
      return true;
    } else
    {
      return false;
    }
  }
}
//This class will handle all screens
//There will be many screens in this program, so
//we will use a switch statement for all screens.

class Screens
{
  Boolean playersSelected;
  Boolean bankrunFichesSelected;
  int stappen = 0;
  Screens()
  {
    playersSelected = false;
    bankrunFichesSelected = false;
  }
  //start beginners spel
  public void screen1()
  {
    fill(style.white);
    textSize(style.textSize);
    text("Money Maker", width/2, height/4);
    text("Interactive tutorial", width/2, height/2);

    next(55);
  }

  public void screen2()
  {
    fill(style.white);
    textSize(style.textSize);
    text("Hoeveel spelers?", width/2, height/5);
    rect(400, 300, 100, 100);
    rect(1200, 300, 100, 100);
    rect(400, 600, 100, 100);
    rect(1200, 600, 100, 100);

    fill(style.black);
    text("3", 400, 325);
    text("4", 1200, 325);
    text("5", 400, 625);
    text("6", 1200, 625);
    
    count++;

    if (overlaps(400, 300, 100, 100, mouseX, mouseY) && mousePressed && count > 20) {
      sounds.buttonPush.play();
      screen = 25; 
      amountOfPlayers = 3;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(1200, 300, 100, 100, mouseX, mouseY) && mousePressed && count > 20) {
      sounds.buttonPush.play();
      screen = 25; 
      amountOfPlayers = 4;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(400, 600, 100, 100, mouseX, mouseY) && mousePressed && count > 20) {
      sounds.buttonPush.play();
      screen = 25; 
      amountOfPlayers = 5;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(1200, 600, 100, 100, mouseX, mouseY) && mousePressed && count > 20) {
      sounds.buttonPush.play();
      screen = 25; 
      amountOfPlayers = 6;
      playersSelected = true;
      count = 0;
    }
  }

  public void screen3()
  {
    fill(style.white);
    rect(400, 450, 500, 500);
    rect(1200, 450, 500, 500);

    fill(style.black);
    textSize(65);
    text("Bord opzetten", 400, 475);
    text("Start spel", 1200, 475);

    bankrun.bankrunSteps = amountOfPlayers +1;

    //This variable makes it so that this screen doesn't get skipped
    //because of this variable you can't go to the next screen within the first 0.5 seconds (30 frames)
    count++;

    //Button for 'bord opzetten'
    if (overlaps(400, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 4; 
      count = 0;
    }
    //Button for 'start spel'
    if (overlaps(1200, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 7;
      count = 0;
    }
  }

  public void screen4()
  {
    imageMode(CENTER);
    image(style.screen4, width/2, height/2, 1600, 900);

    previous(3);
    next(5);
  }

  public void screen5()
  {
    textSize(style.textSize);
    text("Wincondities:", width/2, height/5);
    textSize(60);
    text("-Als alle financieringskaarten op zijn", width/2, 400);
    text("-Als een speler 10 financieringskaarten heeft", width/2, 500);
    text("-Als er 3 bankruns zijn geweest", width/2, 600);

    next(6);
    previous(4);
  }

  public void screen6()
  {
    image(style.screen6, width/2, height/2, 1600, 900);
    noFill();
    strokeWeight(5);

    //productiemarkt
    rect(65, 95, 125, 155);
    //Productiereserve
    rect(65, 825, 125, 120);
    //huizenblokken
    rect(380, 360, 211, 305);
    rect(1100, 205, 460, 64);
    //bankrunmeter
    rect(464, 96, 467, 111);
    //krediet klasse
    rect(1100, 75, 465, 92);
    //rode kaart
    rect(1350, 865, 160, 57);
    //open kaarten
    rect(815, 865, 865, 57);
    //groene kaarten
    rect(275, 865, 160, 57);

    strokeWeight(1);

    //Productiemarkt
    if (overlaps(65, 95, 125, 155, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text1, mouseX, mouseY, 335, 188);
      imageMode(CENTER);
    }

    //Productiereserve
    if (overlaps(65, 825, 125, 120, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text2, mouseX, mouseY-140, 321, 140);
      imageMode(CENTER);
    }

    //huizenblokken
    if (overlaps(380, 360, 211, 305, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text3, mouseX, mouseY);
      imageMode(CENTER);
    }
    if (overlaps(1100, 205, 460, 64, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text3, mouseX, mouseY);
      imageMode(CENTER);
    }

    //bankrunmeter
    if (overlaps(464, 96, 467, 111, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text4, mouseX, mouseY);
      imageMode(CENTER);
    }

    //krediet klasse
    if (overlaps(1100, 75, 465, 92, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text8, mouseX, mouseY);
      imageMode(CENTER);
    }

    //rode kaarten
    if (overlaps(1350, 865, 160, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text5, mouseX-306, mouseY-105);
      imageMode(CENTER);
    }
    //openkaarten
    if (overlaps(815, 865, 865, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text6, mouseX-306, mouseY-105);
      imageMode(CENTER);
    }
    //groene kaarten
    if (overlaps(275, 865, 160, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text7, mouseX, mouseY-105);
      imageMode(CENTER);
    }

    next(3);
  }

  public void screen7()
  {
    imageMode(CENTER);
    image(style.screen7, 300, 700, 650, 400);
    text("De jongste speler begint, draai een financieringskaart", 800, 150);
    text("om en kies of je op een kaart wilt bieden of niet.", 800, 200);

    text("Rechts bovenin de foto zie je de hoeveelheid goederen", 800, 300);
    text("die het bedrijf zoekt ter investering.", 800, 350);
    text("In dit voorbeeld zijn het 2 goederen van de productiemarkt,", 800, 400);
    text("verplaatst daarom 2 goederen naar de Natuurlijke Voorraad.", 800, 450);    

    text("De prijs van een goed correspondeert", 1100, 550);
    text("met de schaal waar het goed in ligt.", 1100, 600);
    text("In dit voorbeeld is het start bod van", 1100, 700);
    text("de kaart dus 5 goud.", 1100, 750);

    previous(3);
    next(8);
  }

  public void screen8()
  {
    text("Draai een financieringskaart om", width/2, height/10);
    text("Ga je bieden?", width/2, height/4.5f);

    if (bankrun.bankrunThisTurn == false)
    {
      textSize(60);
      text("Liggen er al 5 kaarten open? -->", width/3, 800);
      bankrun.bankrunFiche();
    }

    rectMode(CENTER);
    rect(500, height/2, 400, 400);
    rect(1100, height/2, 400, 400);

    fill(style.black);
    text("Ja", 500, height/2);
    text("Nee", 1100, height/2);
    fill(style.white);
    rectMode(CORNER);
    count++;

    if (overlaps(500, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 9; 
      count = 0;
    }
    if (overlaps(1100, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 10; 
      count = 0;
    }
    previous(7);
  }

  public void screen9()
  {
    textMode(CENTER);
    text("Bied minimaal het start bod.", 800, 200);
    text("Nu mogen alle spelers willekeurig hoger bieden,", 800, 250);
    text("de speler met het hoogste bod koopt de kaart.", 800, 300);

    text("Goud komt in de goudreserve.", 800, 400);

    text("Als de speler die aan de beurt is niet het hoogste bod", 800, 500);
    text("heeft gedaan, mag hij/zij op een andere kaart bieden,", 800, 550);
    text("als er nog een openligt. Als er geen kaarten meer open-", 800, 600);
    text("liggen of als je kiest om niet te bieden is de biedronde", 800, 650);
    text("over.", 800, 700);

    next(10);
  }

  public void screen10()
  {
    textSize(60);
    text("Biedronde over", width/2, height/5);
    textSize(40);
    text("De volgende stappen mogen op willekeurige volgorde gedaan worden", width/2, 350);

    rectMode(CENTER);
    rect(300, 650, 400, 400);
    rect(800, 650, 400, 400);
    rect(1300, 650, 400, 400);

    fill(style.black);
    text("Kopen", 300, 650);
    text("Produceren", 800, 650);
    text("Verkopen", 1300, 650);
    fill(style.white);

    count++;

    if (overlaps(300, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 11; 
      count = 0;
    }
    if (overlaps(800, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 12; 
      count = 0;
    }
    if (overlaps(1300, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 15; 
      count = 0;
    }

    text("Einde beurt ->", 1000, 60);
    rectMode(CENTER);
    rect(1200, 50, 100, 50);
    if (overlaps(1200, 50, 100, 50, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 16;
      bankrun.bankrunThisTurn = false;
    }
    previous(8);
  }

  public void screen11()
  {
    imageMode(CENTER);
    text("KOPEN", 800, 200);
    
    text("Je mag elke beurt maximaal 4 goederen per markt kopen,", 800, 300);
    text("de prijs ligt aan de schaal waar de goederen uit komen.", 800, 350);
    
    text("Als de markt leeg is kunnen goederen uit de Natuurlijke", 800, 450);
    text("Voorraad gekocht worden voor 9 goud.", 800, 500);
    
    text("Betaal het goud aan de goudreserve.", 800, 600);

    next(10);
  }

  public void screen12()
  {
    imageMode(CENTER);
    image(style.screen12, 300, 550);
    
    text("PRODUCEREN", 900, 200);
    text("Al je kaarten kunnen 1x", 1000, 300);
    text("produceren in jouw beurt.", 1000, 350);
    
    text("Het aantal goederen dat geproduceerd", 1000, 400);
    text("wordt staat onderaan de kaart.", 1000, 450);

    text("Haal de geproduceerde goederen uit", 1000, 550);
    text("de Natuurlijke Voorraad van de", 1000, 600);
    text("betreffende markt.", 1000, 650);

    next(13);
  }

  public void screen13()
  {
    imageMode(CENTER);
    image(style.screen13, 300, 550);
    
    text("PRODUCEREN", 900, 200);
    text("Met een handelskaart kan je een", 1000, 300);
    text("aantal goederen omruilen met een", 1000, 350);
    text("andere markt. Aantal op de kaart", 1000, 400);
    text("is verplicht, maar gebruik van de", 1000, 450);
    text("kaart niet.", 1000, 500);

    previous(12);
    next(14);
  }

  public void screen14()
  {
    imageMode(CENTER);
    image(style.screen14, 225, 500);
    
    text("PRODUCEREN", 900, 200);
    text("Wanneer je 2 of meer kaarten van dezelfde", 1000, 300);
    text("gilde in je bezit hebt produceert elke", 1000, 350);
    text("kaart van deze gilde, per beurt, één extra goed.", 1000, 400);
    
    text("Handelskaarten geven een extra goed", 1000, 550);
    text("van de al gekozen uitvoer.", 1000, 600);

    previous(13);
    next(10);
  }

  public void screen15()
  {
    imageMode(CENTER);
    image(style.screen15, 300, 550);
    
    text("VERKOPEN", 900, 200);
    text("In deze fase kun je kiezen om al je goederen te verkopen.", 800, 300);
    
    text("Plaats de goederen die je wilt", 1000, 400);
    text("verkopen terug in de markten.", 1000, 450);
    text("De verkoopprijs wordt bepaald", 1000, 500);
    text("door de schaal van de markt.", 1000, 550);
    
    text("Als de markt vol worden goed-", 1000, 650);
    text("eren verkocht voor 1 goud, deze", 1000, 700);
    text("komen in de Natuurlijke Voorraad.", 1000, 750);

    next(10);
  }

  public void screen16()
  {
    imageMode(CENTER);
    text("Gooi nu een kredietdobbelsteen.", 1000, 100);
    text("Waarop is je dobbelsteen geland?", 1000, 200);

    //When you click on the dices, it will bring you to a page about that specific dice.
    //Red 10
    image(style.r10, 400, 400, 200, 200);
    if (overlaps(400, 400, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 17;
    }

    //Red 20
    image(style.r20, 400, 700, 200, 200);
    if (overlaps(400, 700, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 18;
    }

    //Green 10
    image(style.g10, 800, 400, 200, 200);
    if (overlaps(800, 400, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 19;
    }

    //Green 20
    image(style.g20, 800, 700, 200, 200);
    if (overlaps(800, 700, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 20;
    }

    //Blue 10
    image(style.b10, 1200, 400, 200, 200);
    if (overlaps(1200, 400, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 21;
    }

    //Blue 20
    image(style.b20, 1200, 700, 200, 200);    
    if (overlaps(1200, 700, 200, 200, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 22;
    }

    next(23);
  }

  public void screen17()
  {
    imageMode(CENTER);
    text("Haal één goed uit de productiemarkt.", 1000, 100);
    image(style.r10, 400, 400, 200, 200);
    previous(16);
    next(23);
  }

  public void screen18()
  {
    imageMode(CENTER);
    text("Haal twéé goederen uit de productiemarkt.", 1000, 100);
    image(style.r20, 400, 700, 200, 200);
    previous(16);
    next(23);
  }

  public void screen19()
  {
    imageMode(CENTER);
    text("Haal één goed uit de consumptiemarkt.", 1000, 100);    
    image(style.g10, 800, 400, 200, 200);
    previous(16);
    next(23);
  }

  public void screen20()
  {
    imageMode(CENTER);
    text("Haal twéé goederen uit de consumptiemarkt.", 1000, 100);
    image(style.g20, 800, 700, 200, 200);
    previous(16);
    next(23);
  }

  public void screen21()
  {
    imageMode(CENTER);
    text("Verzet het bankrunfiche één stap.", 1000, 100);
    image(style.b10, 1200, 400, 200, 200);
    if (bankrun.bankrunThisTurn == false) {
      bankrun.bankrunCount += 1; 
      bankrun.bankrunThisTurn = true;
    }
    previous(16);
    next(23);
  }

  public void screen22()
  {
    imageMode(CENTER);
    text("Verzet het bankrunfiche twéé stappen.", 1000, 100);
    if (bankrun.bankrunThisTurn == false) {
      bankrun.bankrunCount += 2; 
      bankrun.bankrunThisTurn = true;
    }
    image(style.b20, 1200, 700, 200, 200);
    previous(16);
    next(23);
  }

  public void screen23()
  {
    text("De volgende speler is nu aan de beurt", width/2, height/5);
    text("Herhaal dezelfde stappen", width/2, height/3);
    text("Klik door om naar het begin van het stappenplan te gaan", width/2, 500);

    bankrun.bankrunThisTurn = false;

    next(8);
  }

  //bankrun info screen
  public void screen24()
  {
    text("Verplaats het voorste bankrunfiche met 1 stap", width/2, height/5);
    if(version == 0) {next(8);}
    if(version == 1) {next(36);}
  }

  public void screen25()
  {
    count++;
    fill(style.white);
    textSize(80);
    text("Hoeveel bankrunfiches?", width/2, height/6);
    textSize(40);
    text("Het aantal bankrunfiches bepaald hoelang het spel gaat duren", width/2, height/4);
    textSize(80);
    rect(400, 500, 100, 100);
    rect(800, 500, 100, 100);
    rect(1200, 500, 100, 100);

    fill(style.black);
    text("3", 400, 525);
    text("4", 800, 525);
    text("5", 1200, 525);

    if (overlaps(400, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 3; 
      bankrun.amountOfBankrunFiches = 3;
      bankrunFichesSelected = true;
      count = 0;
    }
    if (overlaps(800, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 3; 
      bankrun.amountOfBankrunFiches = 4;
      bankrunFichesSelected = true;
      count = 0;
    }
    if (overlaps(1200, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 3; 
      bankrun.amountOfBankrunFiches = 5;
      bankrunFichesSelected = true;
      count = 0;
    }
    bankrun.bankrunFichesLeft = bankrun.amountOfBankrunFiches;
  }

  //Bankrun screen
  public void screen26()
  {
    bankrun.bankrun = false;
    textSize(80);
    text("Bankrun!", width/2, height/6);
    textSize(50);
    text("Verplaats 5 goederen van beide kleuren van de", width/2, height/3);
    text("Natuurlijke Voorraad en vul deze aan in de markt", width/2, height/3 + 100);

    next(23);
  }
  //einde beginners spel
  //start volledige spel
  //start volledige spel
  public void screen27()
  {
    fill(style.white);
    text("Hoeveel spelers?", width/2, height/5);
    rect(400, 300, 100, 100);
    rect(1200, 300, 100, 100);
    rect(400, 600, 100, 100);
    rect(1200, 600, 100, 100);

    fill(style.black);
    text("3", 400, 325);
    text("4", 1200, 325);
    text("5", 400, 625);
    text("6", 1200, 625);
    
    count++;

    if (overlaps(400, 300, 100, 100, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 28; 
      amountOfPlayers = 3;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(1200, 300, 100, 100, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 28; 
      amountOfPlayers = 4;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(400, 600, 100, 100, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 28; 
      amountOfPlayers = 5;
      playersSelected = true;
      count = 0;
    }
    if (overlaps(1200, 600, 100, 100, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 28; 
      amountOfPlayers = 6;
      playersSelected = true;
      count = 0;
    }
  }
  public void screen28()
  {
    count++;
    fill(style.white);
    textSize(80);
    text("Hoeveel bankrunfiches?", width/2, height/6);
    textSize(40);
    text("Het aantal fiches bepaalt hoe lang het spel duurt", width/2, height/4);
    textSize(80);
    rect(400, 500, 100, 100);
    rect(800, 500, 100, 100);
    rect(1200, 500, 100, 100);

    fill(style.black);
    text("3", 400, 525);
    text("4", 800, 525);
    text("5", 1200, 525);

    if (overlaps(400, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 29; 
      bankrun.amountOfBankrunFiches = 3;
      bankrunFichesSelected = true;
      count = 0;
    }
    if (overlaps(800, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 29; 
      bankrun.amountOfBankrunFiches = 4;
      bankrunFichesSelected = true;
      count = 0;
    }
    if (overlaps(1200, 500, 100, 100, mouseX, mouseY) && mousePressed && count > 15) {
      sounds.buttonPush.play();
      screen = 29; 
      bankrun.amountOfBankrunFiches = 5;
      bankrunFichesSelected = true;
      count = 0;
    }
    bankrun.bankrunFichesLeft = bankrun.amountOfBankrunFiches;
  }
  public void screen29()
  {
    fill(style.white);
    rect(400, 450, 500, 500);
    rect(1200, 450, 500, 500);

    fill(style.black);
    textSize(65);
    text("Bord opzetten", 400, 475);
    text("Start spel", 1200, 475);

    bankrun.bankrunSteps = amountOfPlayers +1;

    //This variable makes it so that this screen doesn't get skipped
    //because of this variable you can't go to the next screen within the first 0.5 seconds (30 frames)
    count++;

    //Button for 'bord opzetten'
    if (overlaps(400, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 30; 
      count = 0;
    }
    //Button for 'start spel'
    if (overlaps(1200, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 34;
      count = 0;
    }
  }
  public void screen30()
  {
    imageMode(CENTER);
    image(style.screen4, width/2, height/2, 1600, 900);

    previous(29);
    next(31);
  }
  public void screen31()
  {
    imageMode(CENTER);
    image(style.screen31, width/2, height/2, 1600, 900);

    previous(30);
    next(32);
  }
  public void screen32()
  {
    textSize(style.textSize);
    text("Wincondities:", width/2, height/5);
    textSize(60);
    text("-Als alle financieringskaarten op zijn", width/2, 300);
    text("-Als een speler 10 financieringskaarten heeft", width/2, 400);
    text("-Als alle bankruns zijn geweest", width/2, 500);
    text("-Als alle speler failliet zijn", width/2, 600);
    text("-Als er 1 speler niet failliet is", width/2, 700);

    next(33);
    previous(31);
  }
  public void screen33()
  {
    image(style.screen6, width/2, height/2, 1600, 900);
    noFill();
    strokeWeight(5);

    //productiemarkt
    rect(65, 95, 125, 155);
    //Productiereserve
    rect(65, 825, 125, 120);
    //huizenblokken
    rect(380, 360, 211, 305);
    rect(1100, 205, 460, 64);
    //bankrunmeter
    rect(464, 96, 467, 111);
    //krediet klasse
    rect(1100, 75, 465, 92);
    //rode kaart
    rect(1350, 865, 160, 57);
    //open kaarten
    rect(815, 865, 865, 57);
    //groene kaarten
    rect(275, 865, 160, 57);

    strokeWeight(1);

    //Productiemarkt
    if (overlaps(65, 95, 125, 155, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text1, mouseX, mouseY, 335, 188);
      imageMode(CENTER);
    }

    //Productiereserve
    if (overlaps(65, 825, 125, 120, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text2, mouseX, mouseY-140, 321, 140);
      imageMode(CENTER);
    }

    //huizenblokken
    if (overlaps(380, 360, 211, 305, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text9, mouseX, mouseY);
      imageMode(CENTER);
    }
    if (overlaps(1100, 205, 460, 64, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text9, mouseX, mouseY);
      imageMode(CENTER);
    }

    //bankrunmeter
    if (overlaps(464, 96, 467, 111, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text4, mouseX, mouseY);
      imageMode(CENTER);
    }

    //krediet klasse
    if (overlaps(1100, 75, 465, 92, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text11, mouseX, mouseY);
      imageMode(CENTER);
    }

    //rode kaarten
    if (overlaps(1350, 865, 160, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text5, mouseX-306, mouseY-105);
      imageMode(CENTER);
    }
    //openkaarten
    if (overlaps(815, 865, 865, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text6, mouseX-306, mouseY-105);
      imageMode(CENTER);
    }
    //groene kaarten
    if (overlaps(275, 865, 160, 57, mouseX, mouseY))
    {
      imageMode(CORNER);
      image(style.text10, mouseX, mouseY-203);
      imageMode(CENTER);
    }
    
    previous(32);
    next(29);
  }
  public void screen34() 
  {
    textSize(style.textSize);
    text("Aan de beurt komen", width/2, height/5);
    textSize(50);
    text("Iedere speler krijgt de kans om te mogen beginnen met bieden.", width/2, 300);
    text("Dit doe je door voor je beurt te bieden.", width/2, 400);
    text("Dit mag in willekeurige volgorde,", width/2, 600);
    text("de speler die het meest heeft geboden krijgt de eerste beurt,", width/2, 700);
    text("maar is dus wel al goud of krediet kwijt.", width/2, 800);

    previous(29);
    next(35);
  }
  public void screen35()
  {
    imageMode(CENTER);
    image(style.screen7, 300, 700, 650, 400);
    text("Draai een financieringskaart om en kies", 800, 150);
    text("of je op een kaart wilt bieden of niet.", 800, 200);

    text("Rechts bovenin de foto zie je de hoeveelheid goederen", 800, 300);
    text("die het bedrijf zoekt ter investering.", 800, 350);
    text("In dit voorbeeld zijn het 2 goederen van de productiemarkt,", 800, 400);
    text("verplaatst daarom 2 goederen naar de Natuurlijke Voorraad.", 800, 450);    

    text("De prijs van een goed correspondeert", 1100, 550);
    text("met de schaal waar het goed in ligt.", 1100, 600);
    text("In dit voorbeeld is het start bod van", 1100, 700);
    text("de kaart dus 5 goud.", 1100, 750);

    previous(34);
    next(36);
  }
  public void screen36()
  {
    text("Draai een financieringskaart om", width/2, height/10);
    text("Wat ga je doen?", width/2, height/4.5f);

    if (bankrun.bankrunThisTurn == false)
    {
      textSize(60);
      text("Liggen er al 5 kaarten open? -->", width/3, 800);
      bankrun.bankrunFiche();
    }

    rectMode(CENTER);
    rect(500, height/2, 400, 400);
    rect(1100, height/2, 400, 400);

    fill(style.black);
    text("Bieden", 500, height/2);
    text("Aflossen", 1100, height/2);
    fill(style.white);
    rectMode(CORNER);
    count++;

    if (overlaps(500, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 37; 
      count = 0;
    }
    if (overlaps(1100, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 53; 
      count = 0;
    }
    
    previous(35);
  }
  public void screen37()
  {
    imageMode(CENTER);
    text("Bied minimaal het start bod.", 800, 200);
    text("Nu mogen alle spelers willekeurig hoger bieden,", 800, 250);
    text("de speler met het hoogste bod koopt de kaart.", 800, 300);

    text("Goud komt in de goudreserve.", 800, 400);

    text("Als de speler die aan de beurt is niet het hoogste bod", 800, 500);
    text("heeft gedaan, mag hij/zij op een andere kaart bieden,", 800, 550);
    text("als er nog een openligt. Als er geen kaarten meer open-", 800, 600);
    text("liggen of als je kiest om niet te bieden is de biedronde", 800, 650);
    text("over.", 800, 700);

    previous(36);
    next(38);
  }
  public void screen38()
  {
    textSize(60);
    text("Biedronde over", width/2, height/5);
    textSize(40);
    text("De volgende stappen mogen op willekeurige volgorde gedaan worden", width/2, 350);

    rectMode(CENTER);
    rect(300, 650, 400, 400);
    rect(800, 650, 400, 400);
    rect(1300, 650, 400, 400);

    fill(style.black);
    text("Kopen", 300, 650);
    text("Produceren", 800, 650);
    text("Verkopen", 1300, 650);
    fill(style.white);

    count++;

    if (overlaps(300, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 39; 
      count = 0;
    }
    if (overlaps(800, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 40; 
      count = 0;
    }
    if (overlaps(1300, 650, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 43; 
      count = 0;
    }

    text("Einde beurt ->", 1000, 60);
    rectMode(CENTER);
    rect(1200, 50, 100, 50);
    if (overlaps(1200, 50, 100, 50, mouseX, mouseY) && mousePressed) {
      sounds.buttonPush.play();
      screen = 44;
    }
    
    previous(37);
  }
  public void screen39()
  {
    textMode(CENTER);
    text("KOPEN", 800, 200);
    
    text("Je mag elke beurt maximaal 4 goederen per markt kopen,", 800, 300);
    text("de prijs van de goederen is gelijk aan de schaal waar", 800, 350);
    text("ze zich in bevinden.", 800, 400);
    
    text("Als de markt leeg is, haal de goederen uit de Natuurlijke", 800, 500);
    text("Voorraad, deze kosten 9 goud per goed.", 800, 550);

    text("Bepaal de kosten van de goederen die je wilt kopen en", 800, 650);
    text("betaal dit aantal goud aan de goudreserve.", 800, 700);

    next(38);
  }
  public void screen40()
  {
    imageMode(CENTER);
    image(style.screen12, 300, 550);
    
    text("PRODUCEREN", 900, 200);
    text("Al je kaarten kunnen 1x", 1000, 300);
    text("produceren in jouw beurt.", 1000, 350);
    
    text("Het aantal goederen dat geproduceerd", 1000, 400);
    text("wordt staat onderaan de kaart.", 1000, 450);

    text("Haal de geproduceerde goederen uit", 1000, 550);
    text("de Natuurlijke Voorraad van de", 1000, 600);
    text("betreffende markt.", 1000, 650);

    next(41);
  }
  public void screen41()
  {
    imageMode(CENTER);
    image(style.screen13, 300, 550);
    
    text("PRODUCEREN", 900, 200);
    text("Met een handelskaart kan je een", 1000, 300);
    text("aantal goederen omruilen met een", 1000, 350);
    text("andere markt. Aantal op de kaart", 1000, 400);
    text("is verplicht, maar gebruik van de", 1000, 450);
    text("kaart niet.", 1000, 500);

    previous(40);
    next(42);
  }
  public void screen42()
  {
    imageMode(CENTER);
    image(style.screen14, 225, 500);
    
    text("PRODUCEREN", 900, 200);
    text("Wanneer je 2 of meer kaarten van dezelfde", 1000, 300);
    text("gilde in je bezit hebt produceert elke", 1000, 350);
    text("kaart van deze gilde, per beurt, één extra goed.", 1000, 400);
    
    text("Handelskaarten geven een extra goed", 1000, 550);
    text("van de al gekozen uitvoer.", 1000, 600);

    previous(41);
    next(38);
  }
  public void screen43()
  {
    imageMode(CENTER);
    image(style.screen15, 300, 550);
    
    text("VERKOPEN", 900, 200);
    text("In deze fase kun je kiezen om al je goederen te verkopen.", 800, 300);
    
    text("Plaats de goederen die je wilt", 1000, 400);
    text("verkopen terug in de markten.", 1000, 450);
    text("De verkoopprijs wordt bepaald", 1000, 500);
    text("door de schaal van de markt.", 1000, 550);
    
    text("Als de markt vol worden goed-", 1000, 650);
    text("eren verkocht voor 1 goud, deze", 1000, 700);
    text("komen in de Natuurlijke Voorraad.", 1000, 750);

    next(38);
  }
  public void screen44()
  {
    text("Wil je een actiekaart kopen?", width/2, height/4.5f);

    rectMode(CENTER);
    rect(500, height/2, 400, 400);
    rect(1100, height/2, 400, 400);

    fill(style.black);
    text("Ja", 500, height/2);
    text("Nee", 1100, height/2);
    fill(style.white);
    rectMode(CORNER);
    
    count++;

    if (overlaps(500, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 45; 
      count = 0;
    }
    if (overlaps(1100, height/2, 400, 400, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 46; 
      count = 0;
    }
    
    previous(38);
  }
  public void screen45()
  {
    text("Betaal 10 goud of krediet", width/2, height/2);

    next(46);
    previous(44);
  }
  public void screen46()
  {
    imageMode(CENTER);
    text("Er zijn twéé typen dobbelstenen.", 1050, 100);
    text("Gooi eerst een wijkdobbelsteen.", 1050, 150);
    text("(Na de derde bankrun komt er nog één wijk dobbelsteen bij.)", 750, 200);
    text("Wat heb je gegooid?", 400, 575);
    text("Wijk:", 1050, 275);

    count++;
    
    previous(44);
    
    //Molen
    image(style.molen, 1000, 400, 200, 200);
    if (overlaps(1000, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    
    //Boot
    image(style.boot, 1000, 700, 200, 200);
    if (overlaps(1000, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    
    //Vis
    image(style.vis, 1225, 400, 200, 200);
    if (overlaps(1225, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    
    //Wiel
    image(style.wiel, 1225, 700, 200, 200);
    if (overlaps(1225, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    
    //Bakstenen
    image(style.bakstenen, 1450, 400, 200, 200);
    if (overlaps(1450, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    
    //Bloem
    image(style.bloem, 1450,700, 200, 200);
    if (overlaps(1450, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 50;
      count = 0;
    }
    previous(44);

  }
  public void screen47()
  {
    imageMode(CENTER);
    text("Bij rood 10:", 800, 200);
    text("Tel het aantal spelers met 10 of meer krediet", 800, 250);
    text("op de getroffen huizenblokken.", 800, 300);
    text("Bij rood 20:", 800, 375);
    text("Tel het aantal spelers met 20 of meer krediet", 800, 425);
    text("op de getroffen huizenblokken.", 800, 475);
    
    text("Verwijder vervolgens dezelfde hoeveelheid", 800, 600);
    text("goederen uit de bedrijfsmarkt (rood) en voeg", 800, 650);
    text("deze toe aan de Natuurlijke Voorraad.", 800, 700);
    previous(60);
    next(52);
  }
  public void screen48()
  {
    imageMode(CENTER);
    text("Bij groen 10:", 800, 200);
    text("Tel het aantal spelers met 10 of meer krediet", 800, 250);
    text("op de getroffen huizenblokken.", 800, 300);
    text("Bij groen 20:", 800, 375);
    text("Tel het aantal spelers met 20 of meer krediet", 800, 425);
    text("op de getroffen huizenblokken.", 800, 475);
    
    text("Verwijder vervolgens dezelfde hoeveelheid", 800, 600);
    text("goederen uit de consumentenmarkt (groen) en voeg", 800, 650);
    text("deze toe aan de Natuurlijke Voorraad.", 800, 700);
    previous(60);
    next(52);
  }
  public void screen49()
  {
    bankrun.bankrunThisTurn = false;
    count++;
    textSize(40);
    text("Hoeveel spelers hebben 20 of meer krediet op de getroffen huizenblokken?", width/2, height/4);
    int amountOfRects = amountOfPlayers + 1;
    for(int i = 0; i <= amountOfRects; i++)
    {
      fill(style.white);
      rect((width/amountOfRects) * i + (width/amountOfRects)/2, height/2, 100, 100);
      fill(style.black);
      text(i, (width/amountOfRects) * i + (width/amountOfRects)/2, height/2);
      fill(style.white);
      
      if(mousePressed && overlaps((width/amountOfRects) * i + (width/amountOfRects)/2, height/2, 100, 100, mouseX, mouseY) && count > 20)
      {
        bankrun.bankrunCount += 2*i;
        screen = 50;
        count = 0;
      }
    }
  }
  public void screen50()
  {
    imageMode(CENTER);
    text("Dit zijn bij bijvoorbeeld de molen de getroffen wijken.", 800, 200);
    text("Op alle huizenblokken waar de molen staat afgebeeld,", 800, 750);
    text("zal de krediet dobbelsteen effect hebben.", 800, 800);
    image(style.screen50, width/2, 450);
    previous(46);
    next(51);
  }
  public void screen51()
  {
    imageMode(CENTER);
    text("Voorbeeld van een worp:", 800, 150);
    text("4 spelers hebben 10 of meer krediet op deze huizenblokken.", 800, 775);
    text("4 goederen moeten van bedrijfsmarkt naar Natuurlijke Voorraad.", 800, 825);
    image(style.screen51, width/2, 450);
    previous(50);
    next(60);
  }
  public void screen52()
  {
    text("De volgende speler is nu aan de beurt", width/2, height/5);
    text("Herhaal dezelfde stappen", width/2, height/3);
    text("Klik door om naar het begin van het stappenplan te gaan", width/2, 500);

    bankrun.bankrunThisTurn = false;
    next(36);
  }

  public void screen53()
  {
    textSize(style.textSize);
    text("Aflossen", width/2, height/5);
    textSize(60);
    text("Je kunt je krediet aflossen door te betalen met goud", width/2, 300);
    text("of het krediet van een kredietwaardige speler.", width/2, 400);

    previous(36);
    next(54);
  }
  public void screen54()
  {
    imageMode(CENTER);
    textSize(style.textSize);
    text("Krediet klasse omhoog", width/2, height/5);
    textSize(50);
    text("Door je schulden af te lossen ga je een krediet klasse omhoog", width/2, 300);
    image(style.klasse, width/2, height-131);

    previous(53);
    next(44);
  }
  //einde volledige spel 


  //kies spelmode
  public void screen55()
  {
    fill(style.white);
    rect(400, 450, 500, 500);
    rect(1200, 450, 500, 500);

    fill(style.black);
    textSize(65);
    text("Basis spel", 400, 475);
    text("Volledig spel", 1200, 475);

    bankrun.bankrunSteps = amountOfPlayers +1;

    //This variable makes it so that this screen doesn't get skipped
    //because of this variable you can't go to the next screen within the first 0.5 seconds (30 frames)
    count++;

    //Button for 'basis spel'
    if (overlaps(400, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 2; 
      count = 0;
      version = 0;
    }
    //Button for 'volledig spel'
    if (overlaps(1200, 450, 500, 500, mouseX, mouseY) && mousePressed && count > 30) {
      sounds.buttonPush.play();
      screen = 27;
      count = 0;
      version = 1;
    }
  }

  //einde volledige spel

  public void screen56()
  {
    textSize(80);
    text("Game einde!", width/2, height/6);
    textSize(60);
    text("Gebruik het scoreblok om de winnaar te bepalen", width/2, height/4);
    image(style.scoreblok, width/2, height/1.6f, style.scoreblok.width/1.5f, style.scoreblok.height/1.5f);
    textSize(50);
  }
  
  //Scherm voor dobbelsteen blauwe 10 (volledige versie)
  public void screen57()
  {
    bankrun.bankrunThisTurn = false;
    count++;
    textSize(40);
    text("Hoeveel spelers hebben 10 of meer krediet op de getroffen huizenblokken?", width/2, height/4);
    int amountOfRects = amountOfPlayers + 1;
    for(int i = 0; i <= amountOfRects; i++)
    {
      fill(style.white);
      rect((width/amountOfRects) * i + (width/amountOfRects)/2, height/2, 100, 100);
      fill(style.black);
      text(i, (width/amountOfRects) * i + (width/amountOfRects)/2, height/2);
      fill(style.white);
      
      if(mousePressed && overlaps((width/amountOfRects) * i + (width/amountOfRects)/2, height/2, 100, 100, mouseX, mouseY) && count > 40)
      {
    
        stappen = i;
        bankrun.bankrunCount += 2*i;
        screen = 59;
        count = 0;
      }
    }
  }
  
  public void screen58()
  {
    count++;
    bankrun.bankrun = false;
    textSize(80);
    text("Bankrun!", width/2, height/6);
    textSize(50);
    text("Gooi de wijkendobbelsteen", width/2, height/3);
    textSize(35);
    text("Van de huizenblokken met het geworpen symbool moet al het krediet worden afgelost", width/2, height/3 + 100);
    text("Stap 1: bepaal hoeveel krediet afgelost moet worden", width/2, height/3 + 140);
    text("Stap 2: Betaal dat aantal met goud aan de centrale bank", width/2, height/3 + 180);
    text("Stap 3: Als een speler niet genoeg geld heeft om te kunnen aflossen, ga onderhandelen", width/2, height/3 + 220);
    text("Stap 4: Als een speler na het onderhandelen niet alle krediet kan afbetalen, degradeerd deze", width/2, height/3 + 260);
    text("Voor elke speler die degradeerd wordt het bankrunfiche met 2 stappen verplaatst", width/2, height/3 + 300);
    text("Hoeveel spelers zijn er gedegradeerd?", width/2, height/3 + 375);
    
    int amountOfRects = amountOfPlayers + 1;
        for(int i = 0; i <= amountOfRects; i++)
    {
      fill(style.white);
      rect((width/amountOfRects) * i + (width/amountOfRects)/2, 800, 100, 100);
      fill(style.black);
      text(i, (width/amountOfRects) * i + (width/amountOfRects)/2, 800);
      fill(style.white);
      
      if(mousePressed && overlaps((width/amountOfRects) * i + (width/amountOfRects)/2, 800, 100, 100, mouseX, mouseY) && count > 20)
      {
        
        bankrun.bankrunCount += 2*i;
        screen = 52;
        count = 0;
      }
    }
  }
  
  public void screen59()
  {
    text("Verplaats het bankrunfiche met " + stappen + " stappen", width/2, height/2);
    next(52);
  }
  
  public void screen60()
  {
    imageMode(CENTER);
    text("Gooi nu een kredietdobbelsteen.", 1050, 150);
    text("Wat heb je gegooid?", 1050, 200);
    text("Krediet:", 500, 275);
    
    //When you click on the dices, it will bring you to a page about that specific dice.
    //Red 10
    image(style.r10, 300, 400, 200, 200);
    if (overlaps(300, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 47;
      count = 0;
    }

    //Red 20
    image(style.r20, 300, 700, 200, 200);
    if (overlaps(300, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 47;
      count = 0;
    }

    //Green 10
    image(style.g10, 525, 400, 200, 200);
    if (overlaps(525, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 48;
      count = 0;
    }

    //Green 20
    image(style.g20, 525, 700, 200, 200);
    if (overlaps(525, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 48;
      count = 0;
    }

    //Blue 10
    image(style.b10, 750, 400, 200, 200);
    if (overlaps(750, 400, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 57;
      count = 0;
    }

    //Blue 20
    image(style.b20, 750, 700, 200, 200);    
    if (overlaps(750, 700, 200, 200, mouseX, mouseY) && mousePressed && count > 25) {
      sounds.buttonPush.play();
      screen = 57;
      count = 0;
    }
    
    previous(46);
  }
}
public class Sounds {
  
  AudioPlayer buttonPush;
  AudioPlayer bankrun;
  AudioPlayer talking;


  Sounds() {
    buttonPush = minim.loadFile("Buttonpush.mp3"); 
    bankrun = minim.loadFile("Bankrun.mp3");
    talking = minim.loadFile("talking_sound");
  }
}
public class Speler_Tracker {
  int spelers;
  boolean nextplayer;
  Speler_Tracker() {
    spelers = 1; 
    nextplayer = false;
  }

  public void spelers() {
    if (nextplayer) {
      spelers++;
    }
    if (spelers == amountOfPlayers) {
      spelers = 1;
    }
    text("speler: "+ spelers, 900, 600);
    text("end turn", 900, 500);
    if (overlaps(900, 600, 100, 50, mouseX, mouseY) && mousePressed)
    {
      nextplayer = true;
    }
  }
}
//In this class all things style-related
//will be handled. like textsizes and colors etc.
class Style
{
  int textSize;
  int backgroundColor;
  int black;
  int white;

  PImage screen4;
  PImage screen6;
  PImage screen7;
  PImage screen11;
  PImage screen12;
  PImage screen13;
  PImage screen14;
  PImage screen15;
  PImage screen31;
  PImage screen50;
  PImage screen51;

  PImage text1;
  PImage text2;
  PImage text3;
  PImage text4;
  PImage text5;
  PImage text6;
  PImage text7;
  PImage text8;
  PImage text9;
  PImage text10;
  PImage text11;

  PImage r10;
  PImage r20;
  PImage g10;
  PImage g20;
  PImage b10;
  PImage b20;
  PImage red;
  PImage green;
  PImage blue;

  PImage boot, molen, vis, wiel, bakstenen, bloem;

  PImage bankrunfiche;
  PImage klasse;
  PImage bankruncoin;

  PImage BagTip;
  PImage BagJoke;
  PImage BagFact;
  PImage Glossary;

  PImage rechterPijl;
  PImage linkerPijl;

  PImage glossaryKnop;
  PImage glossaryActiekaart;
  PImage glossaryDobbelstenen;
  PImage glossaryFinancieringskaart;
  PImage glossaryGevangenis;
  PImage glossaryGilde;
  PImage glossaryGoud;
  PImage glossaryKrediet;
  PImage glossaryMarkten;
  PImage glossaryPromoveren;
  PImage glossaryKopen;
  PImage glossaryBank;
  PImage glossarySpeech;
  PImage bankrunMeter;
  PImage kredietKlassen;
  PImage gold;
  PImage gevangenis;

  PImage scoreblok;

  Style()
  {
    textSize = 80;
    backgroundColor = color(37, 116, 179);
    black = color(0);
    white = color(255);

    screen4 = loadImage("data/screen4.PNG");
    screen6 = loadImage("data/screen6.PNG");
    screen7 = loadImage("data/screen7.PNG");
    screen12 = loadImage("data/screen12.PNG");
    screen13 = loadImage("data/screen13.PNG");
    screen14 = loadImage("data/screen14.PNG");
    screen15 = loadImage("data/screen15.PNG");
    screen31 = loadImage("data/screen31.png");
    screen50 = loadImage("data/screen50.PNG");
    screen51 = loadImage("data/screen51.PNG");


    text1 = loadImage("data/text1.PNG");
    text2 = loadImage("data/text2.PNG");
    text3 = loadImage("data/text3.PNG");
    text4 = loadImage("data/text4.PNG");
    text5 = loadImage("data/text5.PNG");
    text6 = loadImage("data/text6.PNG");
    text7 = loadImage("data/text7.PNG");
    text8 = loadImage("data/text8.PNG");
    text9 = loadImage("data/text9.PNG");
    text10 = loadImage("data/text10.PNG");
    text11 = loadImage("data/text11.PNG");

    r10 = loadImage("data/10r.png");
    r20 = loadImage("data/20r.png");
    g10 = loadImage("data/10g.png");
    g20 = loadImage("data/20g.png");
    b10 = loadImage("data/10b.png");
    b20 = loadImage("data/20b.png");

    boot = loadImage("data/Boot.png");
    molen = loadImage("data/Molen.png");
    vis = loadImage("data/Vis.png");
    wiel = loadImage("data/Wiel.png");
    bakstenen = loadImage("data/Bakstenen.png");
    bloem = loadImage("data/Bloem.png");

    bankrunfiche = loadImage("data/bankrunfiche.png");
    klasse = loadImage("data/klasse.PNG");
    bankruncoin = loadImage("data/bankruncoin.png");

    BagTip = loadImage("data/whisper.png");
    BagJoke = loadImage("data/laugh.png");
    BagFact = loadImage("data/shrug.png");
    Glossary = loadImage("data/what.png");

    rechterPijl = loadImage("data/rechterpijl.png");
    linkerPijl = loadImage("data/linkerpijl.png");

    glossaryKnop = loadImage("data/glossary_knop.png");
    glossaryActiekaart = loadImage("data/glossary_actiekaarten.png");
    glossaryDobbelstenen = loadImage("data/glossary_dobbelstenen.png");
    glossaryFinancieringskaart = loadImage("data/glossary_financieringskaarten.png");
    glossaryGevangenis = loadImage("data/glossary_gevangenis.png");
    glossaryGilde = loadImage("data/glossary_gilde.png");
    glossaryGoud = loadImage("data/glossary_goud.png");
    glossaryKrediet = loadImage("data/glossary_krediet.png");
    glossaryMarkten = loadImage("data/glossary_productie-consumptie.png");
    glossaryPromoveren = loadImage("data/glossary_promoveren.png");
    glossaryKopen = loadImage("data/glossary_kopen-verkopen.png");
    glossaryBank = loadImage("data/glossary_bank.png");
    glossarySpeech = loadImage("data/glossary_speechbubble.png");
    bankrunMeter = loadImage("data/bankrunMeter.png");
    kredietKlassen = loadImage("data/kredietKlassen.png");
    gold = loadImage("data/gold.png");
    gevangenis = loadImage("data/gevangenis.png");

    scoreblok = loadImage("data/scoreblok.PNG");
  }
}
class RoundCounter {
  int turn = 1;
  int round;
  boolean turnGoesUp;

  RoundCounter() {
  }

  public void Count() {
    if (turn > amountOfPlayers +1 && screens.playersSelected == true) {
      turn = 1;
      round++;
    }

    if (screen == 23 && turnGoesUp == false) {
      turn++;
      turnGoesUp = true;
    }

    if (screen != 23) {
      turnGoesUp = false;
    }
  }
}
  public void settings() {  size(1650, 900); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "PADprocessing" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
